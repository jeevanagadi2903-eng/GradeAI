C:\Users\Lenovo\AppData\Local\Programs\Python\Python313\python.exe app.py
pause